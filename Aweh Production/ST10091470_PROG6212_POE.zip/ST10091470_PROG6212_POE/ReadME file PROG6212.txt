************************************************************
************************************************************
*  Installation of Readme for Task 3 POE(ST10091470)
*
* Please refer to the system requirements for the operating systems
*  supported by the Task 3 POE(ST10091470).
*
************************************************************
************************************************************

************************************************************
*  CONTENTS OF THIS DOCUMENT
************************************************************

This document contains the following sections:

1.  Overview for Task 3 POE (ST10091470)
2.  System Requirements for Task 3 POE(ST10091470)
3.  Installing the Software for Task 3 POE(ST10091470)


************************************************************
* 1.  OVERVIEW
************************************************************


The program for Task 3 POE (ST10091470), In this Portfolio of Evidence, you will be creating an application website that can be used for studdent programme modules. The studenst will be able to
login or if they dont not have an accoun they will be able to register. They will then be able to eneter the Modules onto the database and be able ot call it. That should help the student
know what modules they have selected, the code, credits, class hours and hours per weeks. The studenst can then search for the Modules they seek only if its been uploaded to the database
they also can access the special function of Reminder. This allows the student to set a remidner for a specific task/assignment or even the Module itself, by entering the Module Code and
the date the reminder is set for.


************************************************************
* 2.  SYSTEM REQUIREMENTS
************************************************************


1.  The system must be running on one of the following
    operating systems:
    
    - Microsoft* Windows* Winver10
    - Visual Studio 2019
   

2. The following operating systems are not supported:

    Any version of the following Microsoft operating systems:
    - MS-DOS
    - Windows 3.1
    - Windows NT 3.51
    - Windows 95
    - Windows 98
    - Windows NT 4.0


    Any version of the following operating systems:
    - Linux
    - Windows
    

3.  The system should contain at least the minimum system 
    memory required by the operating system.

4. The following additional software is required 
 
	Microsoft Visual Studio Community 2019 Version 16.9.4
        Microsoft.NET Framework Version 4.8.04084


************************************************************
* 3.  INSTALLING THE SOFTWARE
************************************************************

1. Unzipp the [ST10091470_PROG6212_POE]
    Right click on folder and then select extract all
    to remove it from the zipped file into a normal format.

2. Open File on Microsoft Visual Studio Community 2019 Version 16.9.4
     - Select [ST10091470_PROG6212_POE]
     - Select [ST10091470_PROG6212_POE.sln]

3. Run the Code 


************************************************************
* REFERENCES
************************************************************

1. W3Schools (2019). W3Schools Online Web Tutorials. [online] W3schools.com. Available at: https://www.w3schools.com/.


************************************************************
* 2.  POE Part 2 Corrections
************************************************************

UML diagram as been updated and correctly submitted.
Made use of LINQ.
Students password has been stored in a hash.
Made use of multi-threading
Correction have been implemented.

************************************************************‌