﻿using PROG6212_POE.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG6212_POE
{
    public partial class Enter_Details : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            //Declartions
            string MCode, MName;
            string DateTime;
            int Credit, Week, Hour;

            //Assigning declarations to the text boxes for the user to enter
            MName = ModuleName.Text;
            MCode = ModuleCode.Text;
            DateTime = SDate.Text;
            Credit = Convert.ToInt32(ModuleCredit.Text);
            Week = Convert.ToInt32(Weeks.Text);
            Hour = Convert.ToInt32(Hours.Text);

            //Declaring an object of type Class1
            Class1 program = new Class1(MCode, MName, Credit, Hour, DateTime, Week);

            //Call from Class1
            List<Class1> prlist = Class1.Storage;
            try
            {
                Class1 display = new Class1(MCode, MName, Credit, Hour, DateTime, Week);
                Class1.Storage.Add(display);

                display.SelfStudyCalculation();
                display.RemainderCalculation();

                Response.Write(display.ToString());
                display.AddModules();
                Response.Write($"Module {program.ModuleCode} has been added");

            }
            catch (Exception x)
            {
                Response.Write(x.Message);
            }

            
        }

        protected void btnMM_Click(object sender, EventArgs e)
        {
            Response.Redirect("Manage Modules.aspx");
        }
    }
}

