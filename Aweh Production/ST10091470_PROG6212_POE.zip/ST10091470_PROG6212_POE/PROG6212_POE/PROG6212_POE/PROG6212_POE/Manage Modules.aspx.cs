﻿using PROG6212_POE.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG6212_POE
{
    public partial class Manage_Modules : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

            SqlConnection conn = Connection.GetConnection();
            conn.Open();
            SqlCommand cmd1 = new SqlCommand($"Select * FROM Modules WHERE ModuleCode= '{Search.Text}'", conn);
            cmd1.Parameters.AddWithValue("ModuleCode", Search.Text);
            SqlDataReader reader1;
            reader1 = cmd1.ExecuteReader();
            try
            {
                if (reader1.Read())
                {
                    Display.Items.Add("Student Name:        \t" + reader1["StudentName"].ToString());
                    Display.Items.Add("Module Code:                            \t" + reader1["ModuleCode"].ToString());
                    Display.Items.Add("Module Name:         \t" + reader1["ModuleName"].ToString());
                    Display.Items.Add("Module Credits:      \t" + reader1["Credits"].ToString());
                    Display.Items.Add("Module Hours:        \t" + reader1["Hours"].ToString());
                    Display.Items.Add("Module Start Date:    \t" + reader1["StartDate"].ToString());
                    Display.Items.Add("Module Weeks:        \t" + reader1["Weeks"].ToString());
                    Display.Items.Add("Module Self Study:   \t" + reader1["SelfStudy"].ToString());
                    Display.Items.Add("Module Remainder:    \t" + reader1["Remainder"].ToString());
                }

            }
            catch (Exception error)
            {
                Response.Write(error.Message);
            }


        }

        protected void btnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Enter Details.aspx");
        }

        protected void btnReminder_Click(object sender, EventArgs e)
        {
            Response.Redirect("Reminder.aspx");
        }
    }
}