﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PROG6212_POE.Classes;

namespace PROG6212_POE
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            String StuName = StudentName.Text.ToString();
            String sPassword = StudentPassword.Text.ToString();
            User user = new User();
            user.getUser(StuName);

            

            if (StuName.Equals(StuName))
            {

                Response.Write($"Successfully Logged In");
                Response.Redirect("Enter Details.aspx");

            }
            else
            {
                Response.Write($"Incorrect Credentials Please Try Again");
                Response.Write($"Please Proceed To Registration Page If Credentials Do Not Exist");
                Response.Redirect("");
            }
            Thread.Sleep(TimeSpan.FromSeconds(5));
            StudentName.Text = "Here is a new student text";
        }

       

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Register.aspx");
        }
    }
}
