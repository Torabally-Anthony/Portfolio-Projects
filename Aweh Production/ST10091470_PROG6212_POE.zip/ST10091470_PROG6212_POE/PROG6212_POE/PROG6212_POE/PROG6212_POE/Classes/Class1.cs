﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PROG6212_POE.Classes
{
    public class Class1
    {
        SqlConnection conn = Connection.GetConnection();
        public static List<Class1> Storage = new List<Class1>();
        //Create a list
        public static List<Class1> ProgramList = new List<Class1>();

        public string _moduleCode { get; set; }
        public string ModuleCode
        {
            get { return _moduleCode; }
            set
            {
                if (value.Trim().Length < 3)
                {
                    throw new Exception($"Module Name ({value}) should at least be 3 characters long");
                }
                _moduleCode = value;
            }
        }
        private string ModuleName { get; set; }
        public int Credits { get; set; }
        public int Hours { get; set; }
        public string StartDate { get; set; }
        public int Weeks { get; set; }
        public int Remainder { get; set; }
        public int SelfStudy { get; set; }

        //Default constructor
        public Class1()
        {

        }
        public Class1(string newCode, string newName, int newCredits, int newHours, string newStartDate, int newWeeks)
        {
            ModuleCode = newCode;
            ModuleName = newName;
            Credits = newCredits;
            Hours = newHours;
            StartDate = newStartDate;
            Weeks = newWeeks;

        }
        /// <summary>
        /// Calculations for Self Study
        /// </summary>
        public void SelfStudyCalculation()
        {
            SelfStudy = ((Credits * 10) / Weeks) - Hours;
        }

        /// <summary>
        /// Calculations for Remaining Study
        /// </summary>
        public void RemainderCalculation()
        {
            Remainder = Hours - SelfStudy;
        }

        /// <summary>
        /// Implementing indexer that will return a specific code
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {


            return $"Module Code: {ModuleCode} Module Name: {ModuleName} Module Credits: {Credits} Module Hours: {Hours} Module Start Date: {StartDate} Module Weeks: {Weeks} Self Study Hours: {SelfStudy} Self Study Remainder: {Remainder}";

        }

        public Class1 this[string code]
        {
            get
            {
                return Storage.Find(x => x.ModuleCode.Equals(code));
            }

        }
        /// <summary>
        /// Retrieve data for displaying on SelfStudy button 
        /// </summary>
        /// <returns></returns>
        public Class1 SelfStudyHours()
        {
            string strSelect = $"SELECT * FROM Modules WHERE SelfStudy = (SELECT SelfStudy FROM Modules)";
            using (conn)
            {
                using (SqlCommand cmd = new SqlCommand(strSelect, conn))
                {
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ModuleCode = (string)reader[0];
                            ModuleName = (string)reader[1];
                            Credits = Convert.ToInt32(reader[2]);
                            Hours = Convert.ToInt32(reader[3]);
                            StartDate = (string)reader[4];
                            Weeks = Convert.ToInt32(reader[5]);
                            SelfStudy = Convert.ToInt32(reader[6]);
                            Remainder = Convert.ToInt32(reader[7]);
                        }
                    }
                }
            }
            return new Class1(ModuleCode, ModuleName, Credits, Hours, StartDate, Weeks);
        }

        /// <summary>
        /// Retrieve data for displaying on the REmainigHours button
        /// </summary>
        /// <returns></returns>
        public Class1 RemainderHours()
        {
            string strSelect = $"SELECT * FROM Modules WHERE Remainder = (SELECT Remainder FROM Modules)";
            using (conn)
            {
                using (SqlCommand cmd = new SqlCommand(strSelect, conn))
                {
                    conn.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            ModuleCode = (string)reader[0];
                            ModuleName = (string)reader[1];
                            Credits = Convert.ToInt32(reader[2]);
                            Hours = Convert.ToInt32(reader[3]);
                            StartDate = (string)reader[4];
                            Weeks = Convert.ToInt32(reader[5]);
                            SelfStudy = Convert.ToInt32(reader[6]);
                            Remainder = Convert.ToInt32(reader[7]);
                        }
                    }
                }
            }
            return new Class1(ModuleCode, ModuleName, Credits, Hours, StartDate, Weeks);
        }

        /// <summary>
        /// Inserting data into tables
        /// </summary>
        public void AddModules()
        {
            string strInsert = $"INSERT INTO Modules VALUES('{ModuleCode}','{ModuleName}','{Credits}','{Hours}','{StartDate}','{Weeks}','{SelfStudy}','{Remainder}','{User.StudentName}')";
            SqlCommand cmdInsert = new SqlCommand(strInsert, conn);

            conn.Open();
            cmdInsert.ExecuteNonQuery();
            conn.Close();
        }
        public List<Class1> AllModules()
        {
            string strSelect = $"SELECT * FROM Modules";
            SqlCommand cmdSelect = new SqlCommand(strSelect, conn);
            DataTable myTable = new DataTable();
            DataRow myRow;
            SqlDataAdapter myAdapter = new SqlDataAdapter(cmdSelect);
            List<Class1> prlist = new List<Class1>();

            conn.Open();
            myAdapter.Fill(myTable);

            if (myTable.Rows.Count > 0)
            {
                for (int i = 0; i < myTable.Rows.Count; i++)
                {
                    myRow = myTable.Rows[i];
                    ModuleCode = (string)myRow[0];
                    ModuleName = (string)myRow[1];
                    Credits = Convert.ToInt32(myRow[2]);
                    Hours = Convert.ToInt32(myRow[3]);
                    StartDate = (string)myRow[4];
                    Weeks = Convert.ToInt32(myRow[5]);


                    prlist.Add(new Class1(ModuleCode, ModuleName, Credits, Hours, StartDate, Weeks));
                }
            }

            conn.Close();
            return prlist;
        }
    }
}