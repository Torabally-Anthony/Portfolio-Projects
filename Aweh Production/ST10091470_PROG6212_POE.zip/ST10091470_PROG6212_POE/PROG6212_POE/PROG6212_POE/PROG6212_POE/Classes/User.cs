﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using PROG6212_POE.Classes;

namespace PROG6212_POE.Classes
{
    public class User
    {

        SqlConnection conn = Connection.GetConnection();
        public static string StudentName { get; set; }
        public static string StudentPassword { get; set; }
        public User()
        {

        }
        public User(string studentName, string studentPassword)
        {
            StudentName = studentName;
            StudentPassword = studentPassword;
        }
        public void getUser(string StuName )
        {
            string sqlSelect = $"SELECT * FROM Student WHERE StudentName = '{StuName}'";
            using (conn)
            {
                SqlCommand cmdSelect = new SqlCommand(sqlSelect, conn);

                conn.Open();
                using (SqlDataReader reader = cmdSelect.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        StudentName = (string)reader[0];
                        StudentPassword = (string)reader[0];
                    }
                }
            }
        }
        public void Register()
        {
            String strInsert = $"INSERT INTO Student VALUES('{StudentName}','{StudentPassword}')";
            SqlCommand cmdInsert = new SqlCommand(strInsert, conn);

            conn.Open();
            cmdInsert.ExecuteNonQuery();
            conn.Close();
        }
        public string hashPassword(string UserPassword)
        {
            SHA1CryptoServiceProvider hash = new SHA1CryptoServiceProvider();

            //get the byte representing of the password
            byte[] passwordBytes = Encoding.ASCII.GetBytes(UserPassword);

            //returning the hash encrypted password
            byte[] encryptedBytes = hash.ComputeHash(passwordBytes);

            //returning thhe string
            return Convert.ToBase64String(encryptedBytes);

        }
    }
}