﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;

namespace PROG6212_POE.Classes
{
    public class Connection
    {
        public static SqlConnection GetConnection()
        {
            string fileName = "Database1.mdf";
            string filePath = Path.GetFullPath(fileName).Replace(@"\bin\Debug", @"\Data");
            string strCon = $@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DISD3\source\repos\PROG6212_POE\PROG6212_POE\App_Data\Database1.mdf;Integrated Security=True";

            return new SqlConnection(strCon);
        }
    }
}