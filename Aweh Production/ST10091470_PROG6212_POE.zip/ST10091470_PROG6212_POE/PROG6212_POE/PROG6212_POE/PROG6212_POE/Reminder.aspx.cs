﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG6212_POE
{
    public partial class Reminder : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public void Reminders(string connectionString, string ModuleCode, DateTime DateCalculation)
        {

            string query = "INSERT INTO dbo.Remind(ModuleCode,Date)" +
                "Values (@ModuleCode,@Date)";

            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, cn))
            {
                cmd.Parameters.Add("@ModuleCode", System.Data.SqlDbType.VarChar).Value = ModuleCode;

                cmd.Parameters.Add("@Date", System.Data.SqlDbType.DateTime).Value = DateCalculation;
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string ModuleCode = Remin.Text;
            DateTime cal = Calendar1.SelectedDate;


            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DISD3\source\repos\PROG6212_POE\PROG6212_POE\App_Data\Database1.mdf;Integrated Security=True";
            Reminders(connectionString, ModuleCode, cal);
            Response.Write("REMINDER SUCCESFULLY SUBMITTED");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Logout.aspx");
        }

        protected void btnModH_Click(object sender, EventArgs e)
        {
            Response.Redirect("Manage Modules.aspx");
        }
    }
}