﻿using PROG6212_POE.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG6212_POE
{
    public partial class Register : System.Web.UI.Page
    {
        
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String StudentName = StuName.Text.ToString();
            String StudentPassword = StuPassword.Text.ToString();
            User Stu = new User(StudentName, StudentPassword);
            Stu.hashPassword(StudentPassword);
            Stu.Register();
            Response.Write($"Student {StudentName} has been added");
            Login Log = new Login();
            
            
        }

        protected void btnLog_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}