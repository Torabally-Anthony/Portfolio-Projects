﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    public partial class Rental : System.Web.UI.Page
    {
        public void CreateRental()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            string InsertQuery = "Insert into Rental_ST10091470" +
                   "(RentalIdentity,CarNo,InspectorIdentity,DriverIdentity,RentalFee,StartDate,EndDate) values" +
                   "('" + RentalID.Text + "','" + RentalCarNo.Text + "','" + RentalInspector.Text + "','" + RentalDriver.Text
                   + "','" + RentalFee.Text + "','" + SD.Text + "','" + ED.Text + "')";
            Con.Open();
            SqlCommand cmd = new SqlCommand(InsertQuery, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            Response.Write("<script>alert('VALUES ADDED SUCCESSFULLY')</script>");
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RentalCreate_Click(object sender, EventArgs e)
        {
            CreateRental();
        }

        protected void CarCreate_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}