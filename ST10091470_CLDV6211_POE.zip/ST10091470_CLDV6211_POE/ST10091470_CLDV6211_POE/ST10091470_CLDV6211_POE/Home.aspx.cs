﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    public partial class Home : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("<script>alert('VALUES Updateed SUCCESSFULLY')</script>");
            Response.Redirect("Inspector.aspx");
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlDataAdapter Adapter = new SqlDataAdapter("select * from Inspector_ST10091470 where InspectorIdentity='" + HomeInspectorID.Text + "'AND Email='" + HomeInspectorEmail.Text + "'", Con);
            DataTable DT = new DataTable();
            Adapter.Fill(DT);
            if (DT.Rows.Count > 0)
            {
                
                
            }
            else
            {
                Response.Write("<script>alert('Invaild ')</script>");
            }


        }
    }
}