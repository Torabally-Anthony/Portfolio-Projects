﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    public partial class Return : System.Web.UI.Page
    {
        public void CreateReturn()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            string InsertQuery = "Insert into Refund_ST10091470" +
                   "(ReturnIdentity,RentalIdentity,FineIdentity,ReturnDate,ElapseDate) values" +
                   "('" + ReturnID.Text + "','" + ReturnRentalID.Text + "','" + Fine.Text + "','" + ReturnRD.Text
                   + "','" + ReturnED.Text + "')";
            Con.Open();
            SqlCommand cmd = new SqlCommand(InsertQuery, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            Response.Write("<script>alert('VALUES ADDED SUCCESSFULLY')</script>");
        }

        public void Penalty()
        {
            int PenaltyFee = Convert.ToInt32(ReturnED.Text) * 500;
            String New = Convert.ToString(PenaltyFee);
            Fee.Text = "Fine Is " + New;
        }



        protected void ReturnCreate_Click(object sender, EventArgs e)
        {
            CreateReturn();
            Penalty();
           
        }

        protected void CarCreate_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}