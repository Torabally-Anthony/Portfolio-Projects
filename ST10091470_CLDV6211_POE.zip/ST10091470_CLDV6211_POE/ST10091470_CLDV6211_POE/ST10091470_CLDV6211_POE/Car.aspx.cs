﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    public partial class Car : System.Web.UI.Page
    {
        public void Create()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            string InsertQuery = "Insert into Car_ST10091470" +
                   "(CarNo,CarMake,CarBodyType,Model,ServiceKM,Kilometres,Available) values" +
                   "('" + CarNo.Text + "','" + CarMake.Text + "','" + BodyType.Text + "','" + Model.Text
                   + "','" + ServiceKm.Text + "','" + KmTravel.Text + "','" + Availble.Text + "')";
            Con.Open();
            SqlCommand cmd = new SqlCommand(InsertQuery, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            Response.Write("<script>alert('VALUES ADDED SUCCESSFULLY')</script>");
        }
        public void Delete()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Car_ST10091470 where CarNo='" + CarNo.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('VALUES Deleted SUCCESSFULLY')</script>");

        }

        public void Update()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Car_ST10091470 set CarNo='" + CarNo.Text + "',CarMake='" + CarMake.Text +
                "',CarBodyType='" + BodyType.Text + "',Model='" + Model + "',ServiceKm='" + ServiceKm.Text +
                "',Kilometres='" + KmTravel.Text + "' where CarNo='" + CarNo.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CarDelete_Click(object sender, EventArgs e)
        {
            Delete();
        }

        protected void CarCreate_Click(object sender, EventArgs e)
        {
            Create();
        }

        protected void CarUpdate_Click(object sender, EventArgs e)
        {
            Update();
        }

        protected void CarRefresh_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}