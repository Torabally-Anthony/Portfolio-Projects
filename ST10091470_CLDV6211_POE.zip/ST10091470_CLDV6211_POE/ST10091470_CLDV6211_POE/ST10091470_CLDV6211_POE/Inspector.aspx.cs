﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    public partial class Inspector : System.Web.UI.Page
    {
        public void CreateInspector()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            string InsertQuery = "Insert into Inspector_ST10091470" +
                   "(InspectorIdentity,InspectorName,InspectorSurname,Email,Mobile) values" +
                   "('" + InspectorID.Text + "','" + InspectorName.Text + "','" + InspectorSurname.Text + "','" + InspectorEmail.Text
                   + "','" + InspectorMobile.Text  + "')";
            Con.Open();
            SqlCommand cmd = new SqlCommand(InsertQuery, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            Response.Write("<script>alert('VALUES ADDED SUCCESSFULLY')</script>");
        }
        public void DeleteInspector()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Inspector_ST10091470 where InspectorIdentity='" + InspectorID.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('VALUES Deleted SUCCESSFULLY')</script>");

        }

        public void UpdateInspector()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Inspector_ST10091470 set InspectorIdentity='" + InspectorID.Text + "',InspectorName='" + InspectorName.Text +
                "',InspectorSurname='" + InspectorSurname.Text + "',Email='" + InspectorEmail.Text + "',Mobile='" + InspectorMobile.Text + "' where InspectorIdentity='" + InspectorID.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();

        }

        protected void InspectorCreate_Click(object sender, EventArgs e)
        {
            CreateInspector();
        }

        protected void InspectorUpdate_Click(object sender, EventArgs e)
        {
            UpdateInspector();
        }

        protected void InspectorDelete_Click(object sender, EventArgs e)
        {
            DeleteInspector();
        }

        protected void CarCreate_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}