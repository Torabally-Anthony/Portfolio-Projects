﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace ST10091470_CLDV6211_POE
{
    
    public partial class Driver : System.Web.UI.Page
    {
        public void CreateDriver()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            string InsertQuery = "Insert into Driver_ST10091470" +
                   "(DriverIdentity,DriverName,DriverSurname,HouseNo,StreetName,City,Province,Zipcode,Email,Mobile) values" +
                   "('" + DriverID.Text + "','" + DriverName.Text + "','" + DriverSurname.Text + "','" + HouseNo.Text
                   + "','" + StreetName.Text + "','" + City.Text + "','" + Province.Text + "','" + ZipCode.Text + "','" + DriverEmail.Text + "','" + DriverMobile.Text + "')";
            Con.Open();
            SqlCommand cmd = new SqlCommand(InsertQuery, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            Response.Write("<script>alert('VALUES ADDED SUCCESSFULLY')</script>");
        }
        public void DeleteDriver()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "delete from Driver_ST10091470 where DriverIdentity='" + DriverID.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('VALUES Deleted SUCCESSFULLY')</script>");

        }

        public void UpdateDriver()
        {
            SqlConnection Con = new SqlConnection(@"Data Source=TORA-22\SQLEXPRESS;Initial Catalog=TheRideYouRent_ST10091470;Integrated Security=True");
            SqlCommand cmd = Con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update Driver_ST10091470 set DriverIdentity='" + DriverID.Text + "',DriverName='" + DriverName.Text +
                "',DriverSurname='" + DriverSurname.Text + "',HouseNo='" + HouseNo + "',StreetName='" + StreetName.Text +
                "',City='" + City.Text + "',Province='" + Province.Text + "',Zipcode='" + ZipCode.Text + "',Email='" + DriverEmail.Text + "',Mobile='" + DriverMobile.Text + "' where DriverIdentity='" + DriverID.Text + "'";
            Con.Open();
            cmd.ExecuteNonQuery();
        }
            protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DriverUpdate_Click(object sender, EventArgs e)
        {
            UpdateDriver();
        }

        protected void DriverCreate_Click(object sender, EventArgs e)
        {
            CreateDriver();
        }

        protected void DriverDelete_Click(object sender, EventArgs e)
        {
            DeleteDriver();
        }

        protected void CarCreate_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}