﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ST10091470_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int[] exparray = new int[8];
        public int Groceries = 0;
        public int WaterLight = 0;
        public int TravelCost = 0;
        public int Cellphone = 0;
        public int OtherExpenses = 0;
        public int Rent, Buy = 0;
        public int GMI = 0;
        public int Deduction = 0;
        public int MonthlyExpenses = 0;
        public int Availble = 0;
        public int FinalAmount = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnDisplay1_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
